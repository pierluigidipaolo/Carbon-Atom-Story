//  Created by Pierluigi Di Paolo on 27/03/18.
//  Copyright © 2018 Pierluigi Di Paolo. All rights reserved.

import SceneKit
import UIKit
import Foundation

// Create Class
public class mainClass: UIViewController {
    
    override public func viewDidLoad() {
        super.viewDidLoad()
        
        // Image Declaration
        let image = UIImageView(image: UIImage(named: "paesaggio2.png"))
        
        // Add Image to view
        view.addSubview(image)
        
        // Image Constraint
        image.translatesAutoresizingMaskIntoConstraints = false
        let imageConstraint1 = image.leadingAnchor.constraint(equalTo: self.view.leadingAnchor)
        let imageConstraint2 = image.trailingAnchor.constraint(equalTo: self.view.trailingAnchor)
        let imageConstraint3 = image.topAnchor.constraint(equalTo: self.view.topAnchor)
        let imageConstraint4 = image.bottomAnchor.constraint(equalTo: self.view.bottomAnchor)
        NSLayoutConstraint.activate([imageConstraint4, imageConstraint3, imageConstraint2,imageConstraint1])
        
        // Label declaration
        let label = UILabel()
        label.textAlignment = .center
        label.backgroundColor = UIColor(red: 0/255, green: 0/255, blue: 255/255, alpha: 0.75)
        label.text = " Reaction:  C6H10O5 => CO2  +  H2O "
        label.textColor = UIColor.white
        
        // Add label to view
        view.addSubview(label)
        
        // Label constraint
        label.translatesAutoresizingMaskIntoConstraints = false
        let labelWidthConstraint = label.widthAnchor.constraint(equalToConstant: self.view.frame.width / 3)
        let labelHeightConstraint = label.heightAnchor.constraint(equalToConstant: self.view.frame.height / 10)
        let labelXConstraint = label.centerXAnchor.constraint(equalTo: self.view.centerXAnchor)
        let labelYConstraint = label.centerYAnchor.constraint(equalTo: self.view.centerYAnchor, constant: -self.view.frame.height / 3)
        NSLayoutConstraint.activate([labelXConstraint, labelYConstraint, labelWidthConstraint, labelHeightConstraint])
        
        // Scene View declaration
        let firstView = SCNScene(named: "H2O+CO2.scn")
        let firstViewNode = firstView?.rootNode.childNode(withName: "H2O+CO2", recursively: true)
        let waterNode = firstView?.rootNode.childNode(withName: "H2O", recursively: true)
        let firstView3d = SCNView()
        firstView3d.backgroundColor = UIColor(red: 0/255, green: 202/255, blue: 255/255, alpha: 0)
        firstView3d.scene  = firstView
        firstView3d.autoenablesDefaultLighting = true
        
        // Add scene to view
        view.addSubview(firstView3d)
        firstViewNode?.position = SCNVector3(0,0,-3 )
        firstView3d.allowsCameraControl = true
    
        // Scene constraint
        firstView3d.translatesAutoresizingMaskIntoConstraints = false
        let firstView3dConstraint1 = firstView3d.leadingAnchor.constraint(equalTo: self.view.leadingAnchor)
        let firstView3dConstraint2 = firstView3d.trailingAnchor.constraint(equalTo: self.view.trailingAnchor)
        let firstView3dConstraint3 = firstView3d.topAnchor.constraint(equalTo: self.view.topAnchor)
        let firstView3dConstraint4 = firstView3d.bottomAnchor.constraint(equalTo: self.view.bottomAnchor)
        NSLayoutConstraint.activate([firstView3dConstraint4, firstView3dConstraint3, firstView3dConstraint2,firstView3dConstraint1])

        // Scene Home View declaration
        let homeView3d = SCNView()
        let homeView = SCNScene(named: "home.scn")
        let homeViewNode = homeView?.rootNode.childNode(withName: "home", recursively: true)
        homeView3d.backgroundColor = UIColor(red: 0/255, green: 202/255, blue: 255/255, alpha: 0)
        homeView3d.scene  = homeView
        homeView3d.autoenablesDefaultLighting = true
        homeViewNode?.position = SCNVector3(0,-8,-20)
        // Add scene Home to view
        view.addSubview(homeView3d)
        
        // Scene Home constraint
        homeView3d.translatesAutoresizingMaskIntoConstraints = false
        let homeView3dConstraint1 = homeView3d.leadingAnchor.constraint(equalTo: self.view.leadingAnchor)
        let homeView3dConstraint2 = homeView3d.trailingAnchor.constraint(equalTo: self.view.trailingAnchor)
        let homeView3dConstraint3 = homeView3d.topAnchor.constraint(equalTo: self.view.topAnchor)
        let homeView3dConstraint4 = homeView3d.bottomAnchor.constraint(equalTo: self.view.bottomAnchor)
        NSLayoutConstraint.activate([homeView3dConstraint4, homeView3dConstraint3, homeView3dConstraint2,homeView3dConstraint1])
        
        // Action
        let action1 = SCNAction.moveBy(x: 0, y: 3, z: 0, duration: 5)
        let repAction1 = SCNAction.repeat(action1, count: 1)
        firstViewNode?.runAction(repAction1, forKey: "mymove")
         DispatchQueue.main.asyncAfter(deadline: .now() + 6) {
        let action2 = SCNAction.moveBy(x: 3, y: 10, z: 0, duration: 5)
                let repAction2 = SCNAction.repeat(action2, count: 1)
                waterNode?.runAction(repAction2, forKey: "mymove")
            let action3 = SCNAction.moveBy(x: 0, y: -1, z: 5, duration: 2)
            let repAction3 = SCNAction.repeat(action3, count: 1)
            firstViewNode?.runAction(repAction3, forKey: "mymove")
        }

}
}

