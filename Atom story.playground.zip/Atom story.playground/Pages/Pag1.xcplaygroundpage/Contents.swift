/*:
 ## Chapter 1: 
Our character lies for hundreds of years, bound to atoms of oxygen and hydrogen, in the form of wood: it already has a very long cosmic history behind it, but we shall ignore it.
For it time does not exist and lies within the reach of man.
At any moment, which I, the narrator, decide out of pure caprice to be the year 2010, someone gave him the boot to a fireside.
It was roasted until it separated from the other fellow and still firmly clinging to two former oxygen companions it issued from the chimney and took the path of the air:
Its story, which once was immobile, now turned tumultuous.
*/

//: ---
import PlaygroundSupport
import UIKit

let viewController = mainClass()
viewController.preferredContentSize = CGSize(width: 600, height: 800)
PlaygroundPage.current.liveView = viewController as! PlaygroundLiveViewable

//: [Next](@next)
