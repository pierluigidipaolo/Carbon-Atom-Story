//  Created by Pierluigi Di Paolo on 27/03/18.
//  Copyright © 2018 Pierluigi Di Paolo. All rights reserved.


import SceneKit
import UIKit
import Foundation

// Create Class
public class thirdClass: UIViewController {
    
    override public func viewDidLoad() {
        super.viewDidLoad()
        // Image declaration
        let image = UIImageView(image: UIImage(named: "paesaggio2.png"))
        
        // Add image to view
        view.addSubview(image)
        
        // Image constraint
        image.translatesAutoresizingMaskIntoConstraints = false
        let imageConstraint1 = image.leadingAnchor.constraint(equalTo: self.view.leadingAnchor)
        let imageConstraint2 = image.trailingAnchor.constraint(equalTo: self.view.trailingAnchor)
        let imageConstraint3 = image.topAnchor.constraint(equalTo: self.view.topAnchor)
        let imageConstraint4 = image.bottomAnchor.constraint(equalTo: self.view.bottomAnchor)
        NSLayoutConstraint.activate([imageConstraint4, imageConstraint3, imageConstraint2,imageConstraint1])
        
        // Label declaration
        let label = UILabel()
        label.textAlignment = .center
        label.backgroundColor = UIColor(red: 0/255, green: 0/255, blue: 255/255, alpha: 0.75)
        label.font = UIFont.italicSystemFont(ofSize: 16)
        label.text = " Reaction:  C6H10O5 => CO2  +  H2O "
        label.textColor = UIColor.white
        label.numberOfLines = 0
        label.text = " 6CO2 (6 carbon dioxide molecules) + 6H2O (6 water molecules) + light (catalyst, that is, makes the reaction possible) ==>  C6H12O6  (1 glucose molecule) + 6O2 (6 oxygen molecules) "
        
        // Add label to view
        view.addSubview(label)
        
        // Label constraint
        label.translatesAutoresizingMaskIntoConstraints = false
        let labelWidthConstraint = label.widthAnchor.constraint(equalToConstant: self.view.frame.width / 3)
        let labelHeightConstraint = label.heightAnchor.constraint(equalToConstant: self.view.frame.height / 10)
        let labelXConstraint = label.centerXAnchor.constraint(equalTo: self.view.centerXAnchor)
        let labelYConstraint = label.centerYAnchor.constraint(equalTo: self.view.centerYAnchor, constant: self.view.frame.height / 3)
        NSLayoutConstraint.activate([labelXConstraint, labelYConstraint, labelWidthConstraint, labelHeightConstraint])
        
        // Scene 3D declaration
        var grapes3d = SCNView()
        var grapes = SCNScene(named: "uva.scn")
        let grapesNode = grapes?.rootNode.childNode(withName: "uva", recursively: true)
        grapes3d.backgroundColor = UIColor(red: 0/255, green: 202/255, blue: 255/255, alpha: 0)
        grapes3d.scene  = grapes
        grapes3d.autoenablesDefaultLighting = true
        
        // Add scene 3D to view
        view.addSubview(grapes3d)
        
        // Scene 3D position
        grapesNode?.position = SCNVector3(0,0.5,-2)
        
        // Scene 3D constraint
        grapes3d.translatesAutoresizingMaskIntoConstraints = false
        let grapes3dConstraint1 = grapes3d.leadingAnchor.constraint(equalTo: self.view.leadingAnchor)
        let grapes3dConstraint2 = grapes3d.trailingAnchor.constraint(equalTo: self.view.trailingAnchor)
        let grapes3dConstraint3 = grapes3d.topAnchor.constraint(equalTo: self.view.topAnchor)
        let grapes3dConstraint4 = grapes3d.bottomAnchor.constraint(equalTo: self.view.bottomAnchor)
        NSLayoutConstraint.activate([grapes3dConstraint4, grapes3dConstraint3, grapes3dConstraint2,grapes3dConstraint1])
        
        // Scene 3D declaration
        var carbon3d = SCNView()
        var carbon = SCNScene(named: "carbon.scn")
        let carbonNode = carbon?.rootNode.childNode(withName: "carbon", recursively: true )
        carbon3d.backgroundColor = UIColor(red: 0/255, green: 202/255, blue: 255/255, alpha: 0)
        carbon3d.scene  = carbon
        carbon3d.autoenablesDefaultLighting = true
        
        // Add scene 3D to view
        view.addSubview(carbon3d)
        
        // Scene 3D carbon position
        carbonNode?.position = SCNVector3(0,10.5,-11)
        carbon3d.allowsCameraControl = false
        
        // Scene 3D carbon constraint
        carbon3d.translatesAutoresizingMaskIntoConstraints = false
        let carbon3dConstraint1 = carbon3d.leadingAnchor.constraint(equalTo: self.view.leadingAnchor)
        let carbon3dConstraint2 = carbon3d.trailingAnchor.constraint(equalTo: self.view.trailingAnchor)
        let carbon3dConstraint3 = carbon3d.topAnchor.constraint(equalTo: self.view.topAnchor)
        let carbon3dConstraint4 = carbon3d.bottomAnchor.constraint(equalTo: self.view.bottomAnchor)
        NSLayoutConstraint.activate([carbon3dConstraint4, carbon3dConstraint3, carbon3dConstraint2,carbon3dConstraint1])
        
        // Moviment
        DispatchQueue.main.asyncAfter(deadline: .now() + 4) {
            let action1 = SCNAction.moveBy(x: 0, y: -8, z: 0, duration: 0.5)
            let repAction1 = SCNAction.repeat(action1, count: 1)
            carbonNode?.runAction(repAction1, forKey: "mymove")
        }
       
    }
    
}
