/*:
 ## Chapter 3: 
The atom we are speaking of, accompanied by its two satellites, which maintained it in a gaseous state, was therefore borne by the wind along a row of vines in the year 2015.
Our atom of carbon enters the leaf, colliding with other innumerable molecules of nitrogen and oxygen. It adheres to a large and complicated molecule that activates it, and simultaneously receives the decisive message from the sky, in the flashing form of a packet of solar light: in an instant, it is separated from its oxygen, combined with hydrogen, and finally inserted in a chain, whether long or short does not matter, but it is the chain of life.
Now our atom is inserted into a ring structure, an almost regular hexagon, which is dissolved in water, indeed, in the sap of the vine.
It has entered to form part of a molecule of glucose: Hence it travels, at the slow pace of vegetal juices, from the leaf through the pedicel and by the shoot to the trunk, and from here descends to the almost ripe bunch of grapes.
*/

//: ---
import PlaygroundSupport
import UIKit

let viewController = thirdClass()
viewController.preferredContentSize = CGSize(width: 600, height: 800)
PlaygroundPage.current.liveView = viewController as! PlaygroundLiveViewable

//: [Next](@next)
