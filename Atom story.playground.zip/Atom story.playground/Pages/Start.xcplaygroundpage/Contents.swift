/*:
 
 ## This is the story about the carbon atom and it's extraordinary adventure.
 */ 
//:---
//: ### Move and observe the atom
//:---
import PlaygroundSupport
import UIKit
let viewController = titleClass()
viewController.preferredContentSize = CGSize(width: 600, height: 800)
PlaygroundPage.current.liveView = viewController as! PlaygroundLiveViewable


//: [Next](@next)
