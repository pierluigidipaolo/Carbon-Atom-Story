//  Created by Pierluigi Di Paolo on 27/03/18.
//  Copyright © 2018 Pierluigi Di Paolo. All rights reserved.

import SceneKit
import UIKit
import Foundation

// Create Class
public class titleClass: UIViewController {
    
    override public func viewDidLoad() {
        
        super.viewDidLoad()
        
        view.backgroundColor = UIColor(red: 255/255, green: 255/255, blue: 255/255, alpha: 1)
        
        // Image declaration
        let image1 = UIImageView(image: UIImage(named: "title.png"))
        
        // Add image to view
        view.addSubview(image1)
        
        // Image constraint
        image1.translatesAutoresizingMaskIntoConstraints = false
        let image1WidthConstraint = image1.widthAnchor.constraint(equalToConstant: self.view.frame.width / 3)
        let image1HeightConstraint = image1.heightAnchor.constraint(equalToConstant: self.view.frame.height / 4)
        let image1XConstraint = image1.centerXAnchor.constraint(equalTo: self.view.centerXAnchor)
        let image1YConstraint = image1.centerYAnchor.constraint(equalTo: self.view.centerYAnchor, constant: -self.view.frame.height / 4)
        NSLayoutConstraint.activate([image1XConstraint, image1YConstraint, image1WidthConstraint, image1HeightConstraint])
        
        // View scene declaration
        var atom = SCNScene(named: "atom.scn")
        let atomNode = atom?.rootNode.childNode(withName: "plane", recursively: true)
        var atom3d = SCNView()
        atom3d.backgroundColor = UIColor(red: 0/255, green: 202/255, blue: 255/255, alpha: 0)
        atom3d.scene  = atom
        atom3d.autoenablesDefaultLighting = true
        
        // Add scene to view
        view.addSubview(atom3d)
        atomNode?.position = SCNVector3(0,0,0)
        atom3d.allowsCameraControl = true
        
        // Scene constraint
        atom3d.translatesAutoresizingMaskIntoConstraints = false
        let atomWidthConstraint = atom3d.widthAnchor.constraint(equalToConstant: self.view.frame.width / 1.5)
        let atomHeightConstraint = atom3d.heightAnchor.constraint(equalToConstant: self.view.frame.height / 2)
        let atomXConstraint = atom3d.centerXAnchor.constraint(equalTo: self.view.centerXAnchor)
        let atomYConstraint = atom3d.centerYAnchor.constraint(equalTo: self.view.centerYAnchor, constant: self.view.frame.height / 6)
        NSLayoutConstraint.activate([atomXConstraint, atomYConstraint, atomWidthConstraint, atomHeightConstraint])
        
    }
}
