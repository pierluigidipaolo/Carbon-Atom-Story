/*:
 ## Chapter 4:
It is the destiny of wine to be drunk, and it is the destiny of glucose to be oxidized.
But it was not oxidized immediately: its drinker kept it in his liver for more than a week, well curled up and tranquil, as a reserve aliment for a sudden effort, an effort that he was forced to make the following Monday for the delay to the academy.
Farewell to the hexagonal structure:and became glucose again, and this was dragged by the bloodstream all the way to a minute muscle fiber in the thigh, and here brutally split into two molecules of lactic acid, the grim harbinger of fatigue.
Only later, some minutes after, the panting of the lungs was able to supply the oxygen necessary to quietly oxidize the latter.
So the molecule was again carried by the wind that took it far….
 We will let it fly three times around the world, until 2018. Where he will be ready for another of his adventures.
*/
//: ---
//: ### Click and say hello to the atom 👋🏻
//: ---
 import PlaygroundSupport
 import UIKit
 
let viewController = planeClass()
viewController.preferredContentSize = CGSize(width: 600, height: 800)
PlaygroundPage.current.liveView = viewController as PlaygroundLiveViewable

//: # END
