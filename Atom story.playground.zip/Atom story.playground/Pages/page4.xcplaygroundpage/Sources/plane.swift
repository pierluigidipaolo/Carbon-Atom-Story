//  Created by Pierluigi Di Paolo on 27/03/18.
//  Copyright © 2018 Pierluigi Di Paolo. All rights reserved.

import ARKit
import SceneKit
import UIKit
import Foundation

// Create button
var button = UIButton()

// Create Scene
var plane = SCNScene(named: "plane.scn")
let planeNode = plane?.rootNode.childNode(withName: "plane", recursively: true)

var sea = SCNScene(named: "sea2.scn")
let seaNode = sea?.rootNode.childNode(withName: "orizzonte", recursively: true)

// Scene declaration
var plane3d = SCNView()
var sea3d = SCNView()

// Create class
public class planeClass: UIViewController {
    
    override public func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white

        // Button declaration
        button.layer.cornerRadius = 15
        button.addTarget(self, action: #selector(planeClass.active(_:)), for:.touchUpInside)
        button.backgroundColor = UIColor.red
        button.setTitle("Click Here To End Story", for: .normal)
        
        // Scene attribute
        plane3d.backgroundColor = UIColor(red: 0/255, green: 202/255, blue: 255/255, alpha: 0)
        plane3d.scene  = plane
        plane3d.autoenablesDefaultLighting = true
        view.addSubview(plane3d)
        planeNode?.position = SCNVector3(0,0,-5)

        
        // Add scene 3D to view
        plane3d.addSubview(button)
        
        // Scene 3D constraint
        plane3d.translatesAutoresizingMaskIntoConstraints = false
        let plane3dConstraint1 = plane3d.leadingAnchor.constraint(equalTo: self.view.leadingAnchor)
        let plane3dConstraint2 = plane3d.trailingAnchor.constraint(equalTo: self.view.trailingAnchor)
        let plane3dConstraint3 = plane3d.topAnchor.constraint(equalTo: self.view.topAnchor)
        let plane3dConstraint4 = plane3d.bottomAnchor.constraint(equalTo: self.view.bottomAnchor)
        NSLayoutConstraint.activate([plane3dConstraint4, plane3dConstraint3, plane3dConstraint2,plane3dConstraint1])
        
        // Add scene 3D to view
        sea3d.backgroundColor = UIColor(red: 0/255, green: 202/255, blue: 255/255, alpha: 0)
        sea3d.scene  = sea
        sea3d.autoenablesDefaultLighting = true
        view.addSubview(sea3d)
        seaNode?.position = SCNVector3(-0.2,-0.3,2.8 )
        
        
        sea3d.addSubview(plane3d)
        sea3d.allowsCameraControl = true
       
        // Sea scene 3D constraint
        sea3d.translatesAutoresizingMaskIntoConstraints = false
        let sea3dConstraint1 = sea3d.leadingAnchor.constraint(equalTo: self.view.leadingAnchor)
        let sea3dConstraint2 = sea3d.trailingAnchor.constraint(equalTo: self.view.trailingAnchor)
        let sea3dConstraint3 = sea3d.topAnchor.constraint(equalTo: self.view.topAnchor)
        let sea3dConstraint4 = sea3d.bottomAnchor.constraint(equalTo: self.view.bottomAnchor)
        NSLayoutConstraint.activate([sea3dConstraint4, sea3dConstraint3, sea3dConstraint2,sea3dConstraint1])
        
        // Button contraint
        button.translatesAutoresizingMaskIntoConstraints = false
        let buttonWidthConstraint = button.widthAnchor.constraint(equalToConstant: self.view.frame.width / 4)
        let buttonHeightConstraint = button.heightAnchor.constraint(equalToConstant: self.view.frame.height / 10)
        let buttonXConstraint = button.centerXAnchor.constraint(equalTo: self.view.centerXAnchor)
        let buttonYConstraint = button.centerYAnchor.constraint(equalTo: self.view.centerYAnchor, constant: self.view.frame.height / 3)
        NSLayoutConstraint.activate([ buttonXConstraint, buttonYConstraint, buttonHeightConstraint,buttonWidthConstraint])
        }
    
    // Button function
    @objc func active(_ sender : UIButton) {
        let action1 = SCNAction.moveBy(x: 1, y: 0, z: -40, duration: 5)
        let repAction1 = SCNAction.repeat(action1, count: 1)
        planeNode?.runAction(repAction1, forKey: "mymove")
}
}
