/*:
 ## Chapter 2:
It was caught by the wind, flung down on the earth, lifted ten kilometers high.
It traveled with the wind, for eight years: now high, now low, on the sea and among the clouds, over forests, deserts, and limitless expanses of ice; then it stumbled into capture and the organic adventure.
Carbon, in fact, is a singular element: it is the only element that can bind itself in long stable chains without a great expense of energy, and for life on earth precisely long chains are required.
*/
//: ---
//: ### Click to let the atom travel ✈️
//: ---
 import PlaygroundSupport
 import UIKit
 
let viewController = cloudClass()
viewController.preferredContentSize = CGSize(width: 600, height: 800)
PlaygroundPage.current.liveView = viewController as! PlaygroundLiveViewable
//: [Next](@next)
