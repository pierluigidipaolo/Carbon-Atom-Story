//  Created by Pierluigi Di Paolo on 27/03/18.
//  Copyright © 2018 Pierluigi Di Paolo. All rights reserved.

import SceneKit
import UIKit
import Foundation

// Create button
var button1 = UIButton()

// Scene declaration
var cloud = SCNScene(named: "cloud.scn")
let cloudNode = cloud?.rootNode.childNode(withName: "cloud", recursively: true)
var cloud3d = SCNView()
var sky = SCNScene(named: "sky.scn")
let skyNode = sky?.rootNode.childNode(withName: "sky", recursively: true)

// Scene declaration
var sky3d = SCNView()

// Create class
public class cloudClass: UIViewController {
    
    override public func viewDidLoad() {
        super.viewDidLoad()
       
       // Scene position
        cloud3d.backgroundColor = UIColor(red: 0/255, green: 202/255, blue: 255/255, alpha: 0)
        cloud3d.scene  = cloud
        cloudNode?.position = SCNVector3(1,-2,-3)
        cloud3d.autoenablesDefaultLighting = true
        
        // Add scene to view
        view.addSubview(cloud3d)
        // scene 3D constraint
        cloud3d.translatesAutoresizingMaskIntoConstraints = false
        let cloud3dConstraint1 = cloud3d.leadingAnchor.constraint(equalTo: self.view.leadingAnchor)
        let cloud3dConstraint2 = cloud3d.trailingAnchor.constraint(equalTo: self.view.trailingAnchor)
        let cloud3dConstraint3 = cloud3d.topAnchor.constraint(equalTo: self.view.topAnchor)
        let cloud3dConstraint4 = cloud3d.bottomAnchor.constraint(equalTo: self.view.bottomAnchor)
        NSLayoutConstraint.activate([cloud3dConstraint4, cloud3dConstraint3, cloud3dConstraint2,cloud3dConstraint1])
        
        //
        sky3d.backgroundColor = UIColor(red: 0/255, green: 202/255, blue: 255/255, alpha: 0)
        sky3d.scene  = sky
        sky3d.autoenablesDefaultLighting = true
        view.addSubview(sky3d)
        skyNode?.position = SCNVector3(0,0,2.7   )
        
        
        sky3d.addSubview(cloud3d)
        sky3d.allowsCameraControl = true
        
        // sky scene 3D constraint
        sky3d.translatesAutoresizingMaskIntoConstraints = false
        let sky3dConstraint1 = sky3d.leadingAnchor.constraint(equalTo: self.view.leadingAnchor)
        let sky3dConstraint2 = sky3d.trailingAnchor.constraint(equalTo: self.view.trailingAnchor)
        let sky3dConstraint3 = sky3d.topAnchor.constraint(equalTo: self.view.topAnchor)
        let sky3dConstraint4 = sky3d.bottomAnchor.constraint(equalTo: self.view.bottomAnchor)
        NSLayoutConstraint.activate([sky3dConstraint4, sky3dConstraint3, sky3dConstraint2,sky3dConstraint1])
        
        // Button
        button1.layer.cornerRadius = 15
        button1.addTarget(self, action: #selector(cloudClass.active2(_:)), for:.touchUpInside)
        button1.backgroundColor = UIColor.red
        button1.setTitle("Make The Cloud Leave", for: .normal)
        
        // Add button to view
        view.addSubview(button1)
        
        // Button constraint
        button1.translatesAutoresizingMaskIntoConstraints = false
        let buttonWidthConstraint = button1.widthAnchor.constraint(equalToConstant: self.view.frame.width / 4)
        let buttonHeightConstraint = button1.heightAnchor.constraint(equalToConstant: self.view.frame.height / 10)
        let buttonXConstraint = button1.centerXAnchor.constraint(equalTo: self.view.centerXAnchor)
        let buttonYConstraint = button1.centerYAnchor.constraint(equalTo: self.view.centerYAnchor, constant: self.view.frame.height / 3)
        NSLayoutConstraint.activate([ buttonXConstraint, buttonYConstraint, buttonHeightConstraint,buttonWidthConstraint])

}
    // Button function
    @objc func active2(_ sender : UIButton) {
        let action1 = SCNAction.moveBy(x: -3, y: 6, z: 0, duration: 10)
        let repAction1 = SCNAction.repeat(action1, count: 1)
        cloudNode?.runAction(repAction1, forKey: "mymove")
    }
}
